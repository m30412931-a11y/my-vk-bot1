
import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
from vk_api.keyboard import VkKeyboard, VkKeyboardColor

TOKEN = 'vk1.a.Ca6hGQLsmzQo8_nVd0foBuwEzh9zDMjHTN4OdVDbllJZVniuKdQz4zYyAy05Vinb3OaMQf1G_mIULPNoKs2PjolhMdrmgDEuEx1xWJd5HdKvWFs6wQh_Vdrx4agnaGihh3nDDyP4N4Rho5xpgYqoGPhfg1tMMABO5Sg7hobQkaAORltRVFp9SC9gDvgplztHmhkQjcGQ0IgXovngcJCqqA'

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkLongPoll(vk_session)

def send_msg(user_id, message, keyboard=None, attachment=None):
    post = {'user_id': user_id, 'message': message, 'random_id': 0}
    if keyboard: post['keyboard'] = keyboard.get_keyboard()
    if attachment: post['attachment'] = attachment
    vk_session.method('messages.send', post)

# Главное меню
def menu_main():
    kb = VkKeyboard(one_time=False)
    kb.add_button('💰 Прайс', color=VkKeyboardColor.POSITIVE)
    kb.add_line()
    kb.add_button('🖼 Показать пример', color=VkKeyboardColor.PRIMARY)
    return kb

# Меню Прайса (Вложенное)
def menu_price():
    kb = VkKeyboard(one_time=False)
    kb.add_button('🤖 Боты', color=VkKeyboardColor.SECONDARY)
    kb.add_button('🌐 Сайты', color=VkKeyboardColor.SECONDARY)
    kb.add_line()
    kb.add_button('⬅️ Назад', color=VkKeyboardColor.NEGATIVE)
    return kb

print("Бот с графикой запущен...")

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW and event.to_me:
        msg = event.text.lower()
        uid = event.user_id

        if msg in ["начать", "⬅️ назад"]:
            send_msg(uid, "Вы в главном меню. Выбирай:", menu_main())
            
        elif msg == "💰 прайс":
            # Эффект анимации: меняем клавиатуру на новую
            send_msg(uid, "--- Открываю прайс-лист ---", menu_price())
            
        elif msg == "🖼 показать пример":
            # Вставь сюда ID своего фото, которое загрузил в группу
            # Формат: photo-IDГРУППЫ_IDФОТО
            my_photo = 'photo-237686678_457239017' 
            send_msg(uid, "Вот пример моей работы:", menu_main(), attachment=my_photo)

        elif msg == "🤖 боты":
            send_msg(uid, "Простой бот: от 1000р\nСложный: от 5000р", menu_price())

        elif msg == "🌐 сайты":
            send_msg(uid, "Лендинг: от 3000р", menu_price())


